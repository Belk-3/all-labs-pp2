# we have GLOBAL variable 
# and LOCAL variable

# to get global variable for local function we use func GLOBAL
# to get local variable to global we use NONLOCAL func